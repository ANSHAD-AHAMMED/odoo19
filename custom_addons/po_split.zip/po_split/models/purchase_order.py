from odoo import api, models, fields, _
from collections import defaultdict


class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    split_order_ids = fields.Many2many(
        comodel_name="purchase.order",
        relation="purchase_order_split_rel",
        column1="original_order_id",
        column2="split_order_id",
        string="Split Orders",
    )

    split_order_count = fields.Integer(
        string="Split Order Count",
        compute="_compute_split_order_count",
    )

    is_split_order = fields.Boolean(
        string="Is Split Order",
        default=False,
    )

    original_order_id = fields.Many2one(
        comodel_name="purchase.order",
        string="Original Order",
    )

    def action_view_split_orders(self):
        """ open window for split orders """
        self.ensure_one()
        return {
            "name": _("Split Purchase Orders"),
            "type": "ir.actions.act_window",
            "res_model": "purchase.order",
            "view_mode": "list,form",
            "domain": [("id", "in", self.split_order_ids.ids)],
            "context": {"create": False},
        }

    def action_view_original_order(self):
        """ action to see original order """
        self.ensure_one()
        return {
            "name": _("Original Purchase Order"),
            "type": "ir.actions.act_window",
            "res_model": "purchase.order",
            "view_mode": "form",
            "res_id": self.original_order_id.id,
        }

    @api.depends("split_order_ids")
    def _compute_split_order_count(self):
        """ count how many split orders """
        print('1')
        print('split_order_ids=',self.split_order_ids)
        for record in self:
            record.split_order_count = len(record.split_order_ids)
            print('split_order_count=', record.split_order_count)

    def _get_lowest_price_vendor(self, product):
        """ find lowest price vendor """
        print('2')
        print('product=', product)
        supplierinfo_records = self.env["product.supplierinfo"].search([
            ("product_tmpl_id", "=", product.product_tmpl_id.id),
            ("product_id", "=", False),
        ])

        best_vendor = None
        best_price = None

        for info in supplierinfo_records:

            price = info.price
            print('price=', price)

            if best_price is None or price < best_price:
                best_price = price
                best_vendor = info.partner_id

        return best_vendor, best_price

    def _build_vendor_line_map(self):
        """ group vendor and product lines"""
        print('3')
        vendor_map = defaultdict(list) # Automatically create list for each vendor
        for line in self.order_line:
            vendor, _price = self._get_lowest_price_vendor(
                line.product_id,
            )

            vendor_map[vendor].append(line)

        return vendor_map

    def _create_split_order_for_vendor(self, vendor, lines):
        """ Create purchase order for each vendor """
        print('4')
        self.ensure_one()
        new_order = self.env["purchase.order"].create({
            "partner_id": vendor.id,
            "date_order": self.date_order,
            "date_planned": self.date_planned,
            "company_id": self.company_id.id,

            "is_split_order": True,
            "original_order_id": self.id,
        })

        for line in lines:

            self.env["purchase.order.line"].create({
                "order_id": new_order.id,
                "product_id": line.product_id.id,
                "product_qty": line.product_qty,
                "date_planned": line.date_planned,
            })

        return new_order

    def button_confirm(self):
        print('5')
        orders_to_confirm_normally = (
            self.env["purchase.order"]
        )

        for order in self:
            vendor_map = order._build_vendor_line_map()

            if order.is_split_order or not order.order_line or len(vendor_map) <= 1:
                orders_to_confirm_normally |= order
                continue

            split_orders = self.env["purchase.order"]

            for vendor, lines in vendor_map.items():
                print('abc')
                split_orders |= order._create_split_order_for_vendor(vendor, lines)

            if split_orders:
                order.split_order_ids = [(6, 0, split_orders.ids)]
                order.write({"state": "cancel"})
            else:
                orders_to_confirm_normally |= order

        if orders_to_confirm_normally:
            return super().button_confirm()

        return True
